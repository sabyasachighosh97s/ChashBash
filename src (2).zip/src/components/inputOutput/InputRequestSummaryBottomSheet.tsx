import React, {memo} from 'react';

import {
  Modal,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  View,
} from 'react-native';

import {
  Headline,
  Paragraph,
} from '@components/ui';

import AppIcon from '@components/AppIcon/AppIcon';

import useThemeMode from '@hook/useThemeMode';
import colors from '@themes/colors';

import {InputItem} from './InputItemCard';

export type InputRequestItem = {
  item: InputItem;
  quantity: number;
};

type Props = {
  visible: boolean;

  items: InputRequestItem[];

  onClose: () => void;

  onRemove: (item: InputItem) => void;

  onEdit: (item: InputItem) => void;

  onSubmit?: () => void;
};

const InputRequestSummaryBottomSheet = ({
  visible,
  items,
  onClose,
  onRemove,
  onEdit,
  onSubmit,
}: Props) => {
  const {theme} = useThemeMode();

  const themeColors = theme.colors;

  const totalItems = items.length;

  const totalQuantity = items.reduce(
    (total, current) =>
      total + current.quantity,
    0,
  );

  if (!visible) {
    return null;
  }

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onClose}>

      <View style={styles.overlay}>

        {/* ============================================================
            Backdrop
        ============================================================ */}

        <TouchableOpacity
          activeOpacity={1}
          onPress={onClose}
          style={styles.backdrop}
        />

        {/* ============================================================
            Bottom Sheet
        ============================================================ */}

        <View
          style={[
            styles.sheet,
            {
              backgroundColor:
                themeColors.surface ??
                colors.surface,
            },
          ]}>

          {/* Handle */}

          <View
            style={styles.handle}
          />

          {/* ==========================================================
              Header
          =========================================================== */}

          <View
            style={styles.headerRow}>

            <View
              style={styles.headerIcon}>

              <AppIcon
                type="MaterialIcons"
                name="playlist-check"
                size={23}
                color={colors.primary}
              />

            </View>

            <View
              style={styles.headerContent}>

              <Headline
                size="md"
                textColor={
                  themeColors.text ??
                  colors.text
                }
                style={
                  styles.headerTitle
                }>
                আমার চাহিদা
              </Headline>

              <Paragraph
                size="xs"
                textColor={
                  themeColors
                    .onSurfaceVariant ??
                  colors.subText
                }>
                আপনার পছন্দের উপকরণগুলো
                এখানে দেখুন
              </Paragraph>

            </View>

            <TouchableOpacity
              activeOpacity={0.75}
              onPress={onClose}
              style={styles.closeButton}>

              <AppIcon
                type="MaterialIcons"
                name="close"
                size={21}
                color={
                  themeColors
                    .onSurfaceVariant ??
                  colors.subText
                }
              />

            </TouchableOpacity>

          </View>

          {/* ==========================================================
              Summary
          =========================================================== */}

          <View
            style={[
              styles.summaryBox,
              {
                backgroundColor:
                  `${colors.primary}08`,
                borderColor:
                  `${colors.primary}15`,
              },
            ]}>

            <View
              style={
                styles.summaryItem
              }>

              <View
                style={
                  styles.summaryIcon
                }>

                <AppIcon
                  type="MaterialIcons"
                  name="inventory-2"
                  size={18}
                  color={
                    colors.primary
                  }
                />

              </View>

              <View>
                <Paragraph
                  size="xs"
                  textColor={
                    themeColors
                      .onSurfaceVariant ??
                    colors.subText
                  }>
                  উপকরণ
                </Paragraph>

                <Headline
                  size="sm"
                  textColor={
                    themeColors.text ??
                    colors.text
                  }>
                  {totalItems} টি
                </Headline>
              </View>

            </View>

            <View
              style={
                styles.summaryDivider
              }
            />

            <View
              style={
                styles.summaryItem
              }>

              <View
                style={
                  styles.summaryIcon
                }>

                <AppIcon
                  type="MaterialIcons"
                  name="format-list-numbered"
                  size={18}
                  color={
                    colors.primary
                  }
                />

              </View>

              <View>
                <Paragraph
                  size="xs"
                  textColor={
                    themeColors
                      .onSurfaceVariant ??
                    colors.subText
                  }>
                  মোট পরিমাণ
                </Paragraph>

                <Headline
                  size="sm"
                  textColor={
                    themeColors.text ??
                    colors.text
                  }>
                  {totalQuantity} টি
                </Headline>
              </View>

            </View>

          </View>

          {/* ==========================================================
              Item List
          =========================================================== */}

          <ScrollView
            showsVerticalScrollIndicator={
              false
            }
            contentContainerStyle={
              styles.listContent
            }>

            {items.map(
              ({
                item,
                quantity,
              }) => {

                const itemId =
                  item.id ??
                  item.fid;

                const productName =
                  item.product_name ||
                  item.name ||
                  'ইনপুট আইটেম';

                const firstPrice =
                  item
                    .agri_product_prices?.[0];

                const unitName =
                  firstPrice
                    ?.unit?.unit_name ||
                  firstPrice
                    ?.unit?.unit_sname ||
                  '';

                const price =
                  firstPrice?.sales_price ??
                  firstPrice?.price;

                const packageQuantity =
                  firstPrice?.quantity;

                return (
                  <View
                    key={String(itemId)}
                    style={[
                      styles.itemCard,
                      {
                        borderColor:
                          themeColors.border ??
                          colors.border,

                        backgroundColor:
                          themeColors.surface ??
                          colors.surface,
                      },
                    ]}>

                    {/* Product Icon */}

                    <View
                      style={
                        styles.itemIcon
                      }>

                      <AppIcon
                        type="MaterialIcons"
                        name="eco"
                        size={25}
                        color={
                          colors.primary
                        }
                      />

                    </View>

                    {/* Product Info */}

                    <View
                      style={
                        styles.itemInfo
                      }>

                      <Headline
                        size="sm"
                        numberOfLines={2}
                        textColor={
                          themeColors.text ??
                          colors.text
                        }
                        style={
                          styles.itemName
                        }>
                        {productName}
                      </Headline>

                      <View
                        style={
                          styles.itemMeta
                        }>

                        <Paragraph
                          size="xs"
                          textColor={
                            colors.primary
                          }
                          style={
                            styles.quantityText
                          }>
                          {quantity} টি
                        </Paragraph>

                        {packageQuantity !==
                          undefined &&
                        packageQuantity !==
                          null ? (
                          <Paragraph
                            size="xs"
                            textColor={
                              themeColors
                                .onSurfaceVariant ??
                              colors.subText
                            }>
                            {' '}
                            • প্যাকেট{' '}
                            {packageQuantity}{' '}
                            {unitName}
                          </Paragraph>
                        ) : null}

                        {price !==
                          undefined &&
                        price !== null ? (
                          <Paragraph
                            size="xs"
                            textColor={
                              themeColors
                                .onSurfaceVariant ??
                              colors.subText
                            }>
                            {' '}
                            • ₹{price}
                          </Paragraph>
                        ) : null}

                      </View>

                    </View>

                    {/* Edit */}

                    <TouchableOpacity
                      activeOpacity={0.75}
                      onPress={() =>
                        onEdit(item)
                      }
                      style={
                        styles.editButton
                      }>

                      <AppIcon
                        type="MaterialIcons"
                        name="edit"
                        size={18}
                        color={
                          colors.primary
                        }
                      />

                    </TouchableOpacity>

                    {/* Remove */}

                    <TouchableOpacity
                      activeOpacity={0.75}
                      onPress={() =>
                        onRemove(item)
                      }
                      style={
                        styles.removeButton
                      }>

                      <AppIcon
                        type="MaterialIcons"
                        name="delete-outline"
                        size={19}
                        color={
                          colors.error
                        }
                      />

                    </TouchableOpacity>

                  </View>
                );
              },
            )}

          </ScrollView>

          {/* ==========================================================
              Information
          =========================================================== */}

          <View
            style={
              styles.noticeBox
            }>

            <AppIcon
              type="MaterialIcons"
              name="info-outline"
              size={18}
              color={
                colors.info
              }
            />

            <Paragraph
              size="xs"
              textColor={
                themeColors
                  .onSurfaceVariant ??
                colors.subText
              }
              style={
                styles.noticeText
              }>
              এটি কোনো অনলাইন পেমেন্ট নয়।
              আপনি শুধু কোন কোন কৃষি উপকরণ
              প্রয়োজন তা জানাচ্ছেন।
            </Paragraph>

          </View>

          {/* ==========================================================
              Submit
          =========================================================== */}

          {onSubmit ? (
            <TouchableOpacity
              activeOpacity={0.85}
              onPress={onSubmit}
              style={
                styles.submitButton
              }>

              <AppIcon
                type="MaterialIcons"
                name="send"
                size={21}
                color={
                  colors.textLight
                }
              />

              <Paragraph
                size="sm"
                textColor={
                  colors.textLight
                }
                style={
                  styles.submitText
                }>
                চাহিদা পাঠান
              </Paragraph>

            </TouchableOpacity>
          ) : null}

        </View>

      </View>

    </Modal>
  );
};

export default memo(
  InputRequestSummaryBottomSheet,
);

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    justifyContent: 'flex-end',
  },

  backdrop: {
    ...StyleSheet.absoluteFill,
    backgroundColor:
      'rgba(0,0,0,0.45)',
  },

  sheet: {
    width: '100%',

    maxHeight: '88%',

    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,

    paddingHorizontal: 18,
    paddingTop: 10,
    paddingBottom: 20,

    elevation: 14,

    shadowOffset: {
      width: 0,
      height: -5,
    },

    shadowOpacity: 0.14,
    shadowRadius: 15,
  },

  handle: {
    alignSelf: 'center',

    width: 42,
    height: 4,

    borderRadius: 2,

    backgroundColor:
      colors.border,

    marginBottom: 17,
  },

  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',

    marginBottom: 15,
  },

  headerIcon: {
    width: 44,
    height: 44,

    borderRadius: 14,

    backgroundColor:
      `${colors.primary}10`,

    alignItems: 'center',
    justifyContent: 'center',

    marginRight: 10,
  },

  headerContent: {
    flex: 1,
  },

  headerTitle: {
    lineHeight: 24,
  },

  closeButton: {
    width: 38,
    height: 38,

    borderRadius: 19,

    backgroundColor:
      colors.background,

    alignItems: 'center',
    justifyContent: 'center',
  },

  summaryBox: {
    minHeight: 70,

    borderRadius: 17,

    borderWidth: 1,

    flexDirection: 'row',
    alignItems: 'center',

    paddingHorizontal: 14,

    marginBottom: 12,
  },

  summaryItem: {
    flex: 1,

    flexDirection: 'row',
    alignItems: 'center',
  },

  summaryIcon: {
    width: 36,
    height: 36,

    borderRadius: 11,

    backgroundColor:
      `${colors.primary}10`,

    alignItems: 'center',
    justifyContent: 'center',

    marginRight: 8,
  },

  summaryDivider: {
    width: 1,
    height: 36,

    backgroundColor:
      colors.border,

    marginHorizontal: 10,
  },

  listContent: {
    paddingBottom: 2,
  },

  itemCard: {
    minHeight: 76,

    borderRadius: 17,

    borderWidth: 1,

    padding: 10,

    flexDirection: 'row',
    alignItems: 'center',

    marginBottom: 9,
  },

  itemIcon: {
    width: 48,
    height: 48,

    borderRadius: 14,

    backgroundColor:
      `${colors.primary}0C`,

    alignItems: 'center',
    justifyContent: 'center',

    marginRight: 10,
  },

  itemInfo: {
    flex: 1,

    paddingRight: 6,
  },

  itemName: {
    lineHeight: 20,
  },

  itemMeta: {
    flexDirection: 'row',
    alignItems: 'center',

    marginTop: 4,
  },

  quantityText: {
    fontWeight: '700',
  },

  editButton: {
    width: 38,
    height: 38,

    borderRadius: 12,

    backgroundColor:
      `${colors.primary}0C`,

    alignItems: 'center',
    justifyContent: 'center',

    marginLeft: 4,
  },

  removeButton: {
    width: 38,
    height: 38,

    borderRadius: 12,

    backgroundColor:
      `${colors.error}0A`,

    alignItems: 'center',
    justifyContent: 'center',

    marginLeft: 5,
  },

  noticeBox: {
    flexDirection: 'row',
    alignItems: 'flex-start',

    padding: 10,

    borderRadius: 13,

    backgroundColor:
      `${colors.info}08`,

    marginTop: 5,
  },

  noticeText: {
    flex: 1,

    marginLeft: 8,

    lineHeight: 18,
  },

  submitButton: {
    height: 50,

    borderRadius: 17,

    backgroundColor:
      colors.primary,

    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',

    marginTop: 13,
  },

  submitText: {
    fontWeight: '700',

    marginLeft: 8,
  },
});