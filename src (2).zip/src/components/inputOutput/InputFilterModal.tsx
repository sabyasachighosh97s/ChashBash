import React, {memo} from 'react';
import {
  FlatList,
  Modal,
  StyleSheet,
  TouchableOpacity,
  View,
} from 'react-native';

import {
  Headline,
  Paragraph,
} from '@components/ui';

import AppIcon from '@components/AppIcon/AppIcon';

import useThemeMode from '@hook/useThemeMode';
import colors from '@themes/colors';

import {
  InputFilterItem,
} from './InputCategoryFilter';

type Props = {
  visible: boolean;
  onClose: () => void;
  selectedCategory: string;
  onSelect: (
    item: InputFilterItem,
  ) => void;
  categories: InputFilterItem[];
};

const getCategoryIcon = (
  value: string | number,
) => {
  switch (String(value)) {
    case 'fertilizer':
      return 'eco';

    case 'seed':
      return 'spa';

    case 'pesticide':
      return 'bug-report';

    case 'equipment':
      return 'build';

    default:
      return 'apps';
  }
};

const InputFilterModal = ({
  visible,
  onClose,
  selectedCategory,
  onSelect,
  categories,
}: Props) => {
  const {theme} = useThemeMode();

  const handleSelect = (
    item: InputFilterItem,
  ) => {
    onSelect(item);
    onClose();
  };

  const handleClearFilter = () => {
    const allItem =
      categories.find(
        item =>
          String(item.value) === 'all',
      );

    if (allItem) {
      onSelect(allItem);
    }

    onClose();
  };

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={onClose}>
      
      <View style={styles.overlay}>
        <View
          style={[
            styles.modalContainer,
            {
              backgroundColor:
                theme.colors.surface ??
                colors.surface,
            },
          ]}>

          {/* ============================================================
              Header
          ============================================================ */}

          <View style={styles.header}>

            <View
              style={
                styles.titleContainer
              }>

           

              <View
                style={
                  styles.titleTextContainer
                }>

                <Headline
                  size="sm"
                  textColor={
                    theme.colors.text ??
                    colors.text
                  }
                  style={
                    styles.title
                  }>
                  ক্যাটাগরি অনুযায়ী উপকরণ দেখুন
                </Headline>

               

              </View>

            </View>

            <TouchableOpacity
              activeOpacity={0.8}
              onPress={onClose}
              style={
                styles.closeButton
              }>
              <AppIcon
                type="MaterialCommunityIcons"
                name="close"
                size={22}
                color={
                  colors.error
                }
              />
            </TouchableOpacity>

          </View>

          {/* ============================================================
              Divider
          ============================================================ */}

          <View
            style={[
              styles.divider,
              {
                backgroundColor:
                  theme.colors.outline ??
                  colors.border,
              },
            ]}
          />

          {/* ============================================================
              Categories
          ============================================================ */}

          <FlatList
            data={categories}
            keyExtractor={(
              item,
              index,
            ) =>
              `${item.value}-${index}`
            }
            showsVerticalScrollIndicator={
              false
            }
            contentContainerStyle={
              styles.listContent
            }
            renderItem={({
              item,
            }) => {

              const isSelected =
                String(
                  selectedCategory,
                ) ===
                String(item.value);

              return (
                <TouchableOpacity
                  activeOpacity={0.82}
                  onPress={() =>
                    handleSelect(
                      item,
                    )
                  }
                  style={[
                    styles.categoryItem,
                    {
                      backgroundColor:
                        isSelected
                          ? colors.primary
                          : theme.colors
                              .background ??
                            colors.background,

                      borderColor:
                        isSelected
                          ? colors.primary
                          : theme.colors
                              .outline ??
                            colors.border,
                    },
                  ]}>

                  <View
                    style={
                      styles.categoryLeft
                    }>

                    <View
                      style={[
                        styles.categoryIcon,
                        {
                          backgroundColor:
                            isSelected
                              ? 'rgba(255,255,255,0.15)'
                              : `${colors.primary}10`,
                        },
                      ]}>

                      <AppIcon
                        type="MaterialIcons"
                        name={getCategoryIcon(
                          item.value,
                        )}
                        size={20}
                        color={
                          isSelected
                            ? colors.accent
                            : colors.primary
                        }
                      />

                    </View>

                    <Paragraph
                      size="sm"
                      textColor={
                        isSelected
                          ? colors.textLight
                          : theme.colors
                              .text ??
                            colors.text
                      }
                      style={
                        styles.categoryText
                      }>
                      {item.label}
                    </Paragraph>

                  </View>

                  {isSelected && (
                    <AppIcon
                      type="MaterialCommunityIcons"
                      name="check"
                      size={21}
                      color={
                        colors.textLight
                      }
                    />
                  )}

                </TouchableOpacity>
              );
            }}
          />

          {/* ============================================================
              Clear Filter
          ============================================================ */}

          {selectedCategory !==
            'all' && (
            <TouchableOpacity
              activeOpacity={0.82}
              onPress={
                handleClearFilter
              }
              style={[
                styles.clearButton,
                {
                  borderTopColor:
                    theme.colors
                      .outline ??
                    colors.border,
                },
              ]}>

              <AppIcon
                type="MaterialCommunityIcons"
                name="filter-remove-outline"
                size={20}
                color={
                  colors.primary
                }
              />

              <Paragraph
                size="sm"
                textColor={
                  colors.primary
                }
                style={
                  styles.clearText
                }>
                ফিল্টার সরান
              </Paragraph>

            </TouchableOpacity>
          )}

        </View>
      </View>
    </Modal>
  );
};

export default memo(
  InputFilterModal,
);

const styles =
  StyleSheet.create({

    overlay: {
      flex: 1,

      backgroundColor:
        'rgba(0,0,0,0.45)',

      justifyContent:
        'center',

      alignItems:
        'center',

      paddingHorizontal: 20,
    },

    modalContainer: {
      width: '100%',

      maxHeight: '75%',

      borderRadius: 20,

      overflow: 'hidden',

      elevation: 8,

      shadowColor: '#000',

      shadowOffset: {
        width: 0,
        height: 4,
      },

      shadowOpacity: 0.2,

      shadowRadius: 8,
    },

    header: {
      minHeight: 70,

      flexDirection: 'row',

      alignItems: 'center',

      justifyContent:
        'space-between',

      paddingLeft: 16,

      paddingRight: 12,
    },

    titleContainer: {
      flex: 1,

      flexDirection: 'row',

      alignItems: 'center',
    },

    titleIcon: {
      width: 42,
      height: 42,

      borderRadius: 13,

      backgroundColor:
        `${colors.primary}10`,

      alignItems: 'center',

      justifyContent:
        'center',
    },

    titleTextContainer: {
      flex: 1,

      marginLeft: 10,
    },

    title: {
     
    },

    closeButton: {
      width: 38,
      height: 38,

      borderRadius: 19,

      alignItems: 'center',

      justifyContent: 'center',

      marginLeft: 10,

      backgroundColor:
        '#FFEBEE',
    },

    divider: {
      height:
        StyleSheet.hairlineWidth,

      width: '100%',
    },

    listContent: {
      padding: 16,
    },

    categoryItem: {
      minHeight: 52,

      borderWidth: 1,

      borderRadius: 14,

      paddingHorizontal: 10,

      marginBottom: 10,

      flexDirection: 'row',

      alignItems: 'center',

      justifyContent:
        'space-between',
    },

    categoryLeft: {
      flex: 1,

      flexDirection: 'row',

      alignItems: 'center',
    },

    categoryIcon: {
      width: 34,
      height: 34,

      borderRadius: 11,

      alignItems: 'center',

      justifyContent:
        'center',
    },

    categoryText: {
      flex: 1,

      marginLeft: 9,

      fontWeight: '600',
    },

    clearButton: {
      minHeight: 50,

      borderTopWidth:
        StyleSheet.hairlineWidth,

      flexDirection: 'row',

      alignItems: 'center',

      justifyContent:
        'center',

      paddingHorizontal: 16,
    },

    clearText: {
      marginLeft: 7,

      fontWeight: '600',
    },
  });