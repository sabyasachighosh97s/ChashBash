import React, {memo, useState} from 'react';

import {
  Image,
  LayoutAnimation,
  Platform,
  StyleProp,
  StyleSheet,
  TouchableOpacity,
  UIManager,
  View,
  ViewStyle,
} from 'react-native';

import {Headline, Paragraph} from '@components/ui';

import AppIcon from '@components/AppIcon/AppIcon';

import useThemeMode from '@hook/useThemeMode';
import colors from '@themes/colors';

/* ==========================================================================
   Types
========================================================================== */

export type InputItemPrice = {
  prod_price_id?: string | number;
  quantity?: number | string;
  sales_price?: number | string;
  price?: number | string;

  unit?: {
    unit_name?: string;
    unit_sname?: string;
    fid?: string | number;
  };
};

export type InputItem = {
  id?: string | number;
  fid?: string | number;

  product_name?: string;
  name?: string;
  product_code?: string;
  description?: string;

  image?: string;
  image_url?: string;

  category?: string;
  sub_category?: string;

  agri_product_prices?: InputItemPrice[];
};

interface Props {
  item: InputItem;
onPress?: (item: InputItem) => void;

  onBuy?: (item: InputItem) => void;

  onRemove?: (item: InputItem) => void;

  selected?: boolean;

  style?: StyleProp<ViewStyle>;
}

/* ==========================================================================
   Android Layout Animation
========================================================================== */

if (
  Platform.OS === 'android' &&
  UIManager.setLayoutAnimationEnabledExperimental
) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

/* ==========================================================================
   Category Icon
========================================================================== */

const getCategoryIcon = (category?: string) => {
  switch (category) {
    case 'fertilizer':
      return 'eco';

    case 'seed':
      return 'spa';

    case 'pesticide':
      return 'bug-report';

    case 'equipment':
      return 'build';

    default:
      return 'category';
  }
};

/* ==========================================================================
   Component
========================================================================== */

const InputItemCard = ({
  item,
  onBuy,
   onPress,
  onRemove,
  selected = false,
  style,
}: Props) => {
  const {theme} = useThemeMode();

  const themeColors = theme.colors;

  const [expanded, setExpanded] = useState(false);

  /* ------------------------------------------------------------------------
     Product information
  ------------------------------------------------------------------------ */

  const productName =
    item?.product_name ||
    item?.name ||
    'ইনপুট আইটেম';

  const category = item?.category || '';

  const subCategory = item?.sub_category || '';

  const firstPrice =
    item?.agri_product_prices?.[0];

  const price =
    firstPrice?.sales_price ??
    firstPrice?.price;

  const packageQuantity =
    firstPrice?.quantity;

  const unitName =
    firstPrice?.unit?.unit_name ||
    firstPrice?.unit?.unit_sname ||
    '';

  const productImage =
    item?.image ||
    item?.image_url;

  /* ------------------------------------------------------------------------
     Text
  ------------------------------------------------------------------------ */

  const priceText =
    price !== undefined &&
    price !== null
      ? `₹${price}`
      : '';

  const packageText =
    packageQuantity !== undefined &&
    packageQuantity !== null &&
    packageQuantity !== ''
      ? `${packageQuantity} ${unitName}`.trim()
      : unitName;

  /* ------------------------------------------------------------------------
     Toggle details
  ------------------------------------------------------------------------ */

  const toggleDetails = () => {
    LayoutAnimation.configureNext(
      LayoutAnimation.Presets.easeInEaseOut,
    );

    setExpanded(value => !value);
  };

  /* ==========================================================================
     UI
  ========================================================================== */

  return (
    <View
      style={[
        styles.wrapper,
        style,
      ]}>

      {/* ====================================================================
          SINGLE CARD
          Everything including expanded details stays inside this card.
      ==================================================================== */}

      <View
        style={[
          styles.card,
          {
            backgroundColor:
              themeColors.surface ??
              colors.surface,

            borderColor: selected
              ? colors.primary
              : themeColors.border ??
                colors.border,

            borderWidth: selected
              ? 1.5
              : 1,
          },
        ]}>

        {/* ================================================================
            Main Product Area
        ================================================================= */}



        <View style={styles.mainContent}>

          {/* ==============================================================
              Product image
          ============================================================== */}

          <View
            style={[
              styles.imageContainer,
              {
                backgroundColor:
                  `${colors.primary}0C`,
              },
            ]}>

            {productImage ? (
              <Image
                source={{
                  uri: productImage,
                }}
                style={
                  styles.productImage
                }
                resizeMode="cover"
              />
            ) : (
              <View
                style={
                  styles.imageFallback
                }>

                <View
                  style={
                    styles.imageIconCircle
                  }>

                  <AppIcon
                    type="MaterialIcons"
                    name={getCategoryIcon(
                      category,
                    )}
                    size={38}
                    color={
                      colors.primary
                    }
                  />

                </View>

              </View>
            )}

            {/* Selected */}

            {selected && (
              <View
                style={
                  styles.selectedBadge
                }>

                <AppIcon
                  type="MaterialIcons"
                  name="check"
                  size={15}
                  color={
                    colors.textLight
                  }
                />

              </View>
            )}

          </View>

          {/* ==============================================================
              Product content
          ============================================================== */}

          <View
            style={
              styles.content
            }>

            {/* Product title */}
<TouchableOpacity
  activeOpacity={0.9}
  onPress={() => onPress?.(item)}
>
            <View
              style={
                styles.titleRow
              }>

              <Headline
                size="sm"
                numberOfLines={2}
                textColor={
                  themeColors.text ??
                  colors.text
                }
                style={
                  styles.productName
                }>
                {productName}
              </Headline>

            </View>
            

            {/* Price */}

            {(priceText ||
              packageText) && (
              <View
                style={
                  styles.priceRow
                }>

                {priceText ? (
                  <Headline
                    size="sm"
                    textColor={
                      colors.primary
                    }
                    style={
                      styles.price
                    }>
                    {priceText}
                  </Headline>
                ) : null}

                {packageText ? (
                  <Paragraph
                    size="xs"
                    numberOfLines={1}
                    textColor={
                      themeColors
                        .onSurfaceVariant ??
                      colors.subText
                    }
                    style={
                      styles.unitText
                    }>
                    / {packageText}
                  </Paragraph>
                ) : null}

              </View>
            )}
</TouchableOpacity>
            {/* Actions */}

            <View
              style={
                styles.actionRow
              }>

              {/* Details */}

              <TouchableOpacity
                activeOpacity={0.8}
                onPress={
                  toggleDetails
                }
                style={[
                  styles.detailsButton,
                  {
                    borderColor:
                      expanded
                        ? colors.primary
                        : `${colors.primary}35`,

                    backgroundColor:
                      expanded
                        ? `${colors.primary}0C`
                        : 'transparent',
                  },
                ]}>

                <AppIcon
                  type="MaterialIcons"
                  name={
                    expanded
                      ? 'keyboard-arrow-up'
                      : 'visibility'
                  }
                  size={18}
                  color={
                    colors.primary
                  }
                />

                <Paragraph
                  size="xs"
                  textColor={
                    colors.primary
                  }
                  style={
                    styles.detailsText
                  }>
                  {expanded
                    ? 'বিস্তারিত বন্ধ'
                    : 'বিস্তারিত'}
                </Paragraph>

              </TouchableOpacity>

              {/* Select / Remove */}

              {selected ? (
                <TouchableOpacity
                  activeOpacity={0.85}
                  onPress={() =>
                    onRemove?.(item)
                  }
                  style={
                    styles.removeButton
                  }>

                  <Paragraph
                    size="xs"
                    textColor={
                      colors.error
                    }
                    style={
                      styles.removeText
                    }>
                    বাদ দিন
                  </Paragraph>

                  <AppIcon
                    type="MaterialIcons"
                    name="delete-outline"
                    size={17}
                    color={
                      colors.error
                    }
                  />

                </TouchableOpacity>
              ) : (
                <TouchableOpacity
                  activeOpacity={0.85}
                  onPress={() =>
                    onBuy?.(item)
                  }
                  style={
                    styles.buyButton
                  }>

                  <Paragraph
                    size="xs"
                    textColor={
                      colors.textLight
                    }
                    style={
                      styles.buyText
                    }>
                    নিতে চাই
                  </Paragraph>

                  <AppIcon
                    type="MaterialIcons"
                    name="arrow-forward"
                    size={17}
                    color={
                      colors.textLight
                    }
                  />

                </TouchableOpacity>
              )}

            </View>

          </View>

        </View>


        {/* ==================================================================
            Expanded Details
            IMPORTANT:
            This is INSIDE the same card.
        ================================================================== */}

        {expanded && (
          <View
            style={[
              styles.expandedSection,
              {
                borderTopColor:
                  themeColors.outline ??
                  colors.border,
              },
            ]}>

            {/* Subtle divider */}

            <View
              style={
                styles.expandedDivider
              }
            />

            {/* Details title */}

            <View
              style={
                styles.expandedHeadingRow
              }>

              <View
                style={
                  styles.expandedHeadingIcon
                }>

                <AppIcon
                  type="MaterialIcons"
                  name="info-outline"
                  size={18}
                  color={
                    colors.primary
                  }
                />

              </View>

              <View
                style={
                  styles.expandedHeadingContent
                }>

                <Headline
                  size="sm"
                  textColor={
                    themeColors.text ??
                    colors.text
                  }>
                  উপকরণের বিস্তারিত
                </Headline>

              </View>

            </View>

            {/* Description */}

            {item.description ? (
              <View
                style={
                  styles.descriptionBox
                }>

                <Paragraph
                  size="sm"
                  textColor={
                    themeColors.text ??
                    colors.text
                  }
                  style={
                    styles.descriptionText
                  }>
                  {item.description}
                </Paragraph>

              </View>
            ) : null}

            {/* Information */}

            <View
              style={
                styles.infoGrid
              }>

              {/* Category */}

              {category ? (
                <View
                  style={
                    styles.infoItem
                  }>

                  <View
                    style={
                      styles.infoIcon
                    }>

                    <AppIcon
                      type="MaterialIcons"
                      name="category"
                      size={17}
                      color={
                        colors.primary
                      }
                    />

                  </View>

                  <View
                    style={
                      styles.infoTextContainer
                    }>

                    <Paragraph
                      size="xs"
                      textColor={
                        themeColors
                          .onSurfaceVariant ??
                        colors.subText
                      }>
                      ক্যাটাগরি
                    </Paragraph>

                    <Paragraph
                      size="sm"
                      textColor={
                        themeColors.text ??
                        colors.text
                      }
                      style={
                        styles.infoValue
                      }
                      numberOfLines={1}>
                      {category}
                    </Paragraph>

                  </View>

                </View>
              ) : null}

              {/* Sub category */}

              {subCategory ? (
                <View
                  style={
                    styles.infoItem
                  }>

                  <View
                    style={
                      styles.infoIcon
                    }>

                    <AppIcon
                      type="MaterialIcons"
                      name="account-tree"
                      size={17}
                      color={
                        colors.primary
                      }
                    />

                  </View>

                  <View
                    style={
                      styles.infoTextContainer
                    }>

                    <Paragraph
                      size="xs"
                      textColor={
                        themeColors
                          .onSurfaceVariant ??
                        colors.subText
                      }>
                      সাব-ক্যাটাগরি
                    </Paragraph>

                    <Paragraph
                      size="sm"
                      textColor={
                        themeColors.text ??
                        colors.text
                      }
                      style={
                        styles.infoValue
                      }
                      numberOfLines={1}>
                      {subCategory}
                    </Paragraph>

                  </View>

                </View>
              ) : null}

              {/* Package */}

              {packageText ? (
                <View
                  style={
                    styles.infoItem
                  }>

                  <View
                    style={
                      styles.infoIcon
                    }>

                    <AppIcon
                      type="MaterialIcons"
                      name="inventory-2"
                      size={17}
                      color={
                        colors.primary
                      }
                    />

                  </View>

                  <View
                    style={
                      styles.infoTextContainer
                    }>

                    <Paragraph
                      size="xs"
                      textColor={
                        themeColors
                          .onSurfaceVariant ??
                        colors.subText
                      }>
                      প্যাকেজ
                    </Paragraph>

                    <Paragraph
                      size="sm"
                      textColor={
                        themeColors.text ??
                        colors.text
                      }
                      style={
                        styles.infoValue
                      }
                      numberOfLines={1}>
                      {packageText}
                    </Paragraph>

                  </View>

                </View>
              ) : null}

              {/* Product code */}

              {item.product_code ? (
                <View
                  style={
                    styles.infoItem
                  }>

                  <View
                    style={
                      styles.infoIcon
                    }>

                    <AppIcon
                      type="MaterialIcons"
                      name="qr-code"
                      size={17}
                      color={
                        colors.primary
                      }
                    />

                  </View>

                  <View
                    style={
                      styles.infoTextContainer
                    }>

                    <Paragraph
                      size="xs"
                      textColor={
                        themeColors
                          .onSurfaceVariant ??
                        colors.subText
                      }>
                      পণ্য কোড
                    </Paragraph>

                    <Paragraph
                      size="sm"
                      textColor={
                        themeColors.text ??
                        colors.text
                      }
                      style={
                        styles.infoValue
                      }
                      numberOfLines={1}>
                      {item.product_code}
                    </Paragraph>

                  </View>

                </View>
              ) : null}

            </View>

            {/* Collapse */}

            <TouchableOpacity
              activeOpacity={0.8}
              onPress={
                toggleDetails
              }
              style={
                styles.collapseButton
              }>

              <Paragraph
                size="xs"
                textColor={
                  colors.primary
                }
                style={
                  styles.collapseText
                }>
                বিস্তারিত বন্ধ করুন
              </Paragraph>

              <AppIcon
                type="MaterialIcons"
                name="keyboard-arrow-up"
                size={19}
                color={
                  colors.primary
                }
              />

            </TouchableOpacity>

          </View>
        )}

      </View>

    </View>
  );
};

export default memo(
  InputItemCard,
);

/* ==========================================================================
   Styles
========================================================================== */

const styles = StyleSheet.create({
  wrapper: {
    width: '100%',

    marginBottom: 13,
  },

  /* ==========================================================================
     Single unified card
  ========================================================================== */

  card: {
    width: '100%',

    borderRadius: 20,

    padding: 10,

    shadowOffset: {
      width: 0,
      height: 3,
    },

    shadowOpacity: 0.06,

    shadowRadius: 8,

    elevation: 2,

    overflow: 'hidden',
  },

  /* ==========================================================================
     Main product section
  ========================================================================== */

  mainContent: {
    width: '100%',

    flexDirection: 'row',

    alignItems: 'center',
  },

  imageContainer: {
    width: 94,

    height: 126,

    borderRadius: 16,

    alignItems: 'center',

    justifyContent: 'center',

    overflow: 'hidden',
  },

  productImage: {
    width: '100%',

    height: '100%',
  },

  imageFallback: {
    flex: 1,

    width: '100%',

    alignItems: 'center',

    justifyContent: 'center',
  },

  imageIconCircle: {
    width: 62,

    height: 62,

    borderRadius: 31,

    alignItems: 'center',

    justifyContent: 'center',

    backgroundColor:
      `${colors.primary}10`,
  },

  selectedBadge: {
    position: 'absolute',

    top: 7,

    right: 7,

    width: 25,

    height: 25,

    borderRadius: 13,

    backgroundColor:
      colors.primary,

    alignItems: 'center',

    justifyContent: 'center',
  },

  content: {
    flex: 1,

    marginLeft: 13,

    paddingVertical: 2,
  },

  titleRow: {
    width: '100%',

    flexDirection: 'row',

    alignItems: 'flex-start',
  },

  productName: {
    flex: 1,

    paddingRight: 5,

    lineHeight: 21,
  },

  priceRow: {
    flexDirection: 'row',

    alignItems: 'baseline',

    marginTop: 8,
  },

  price: {
    lineHeight: 20,
  },

  unitText: {
    marginLeft: 5,

    lineHeight: 18,

    flexShrink: 1,
  },

  /* ==========================================================================
     Actions
  ========================================================================== */

  actionRow: {
    width: '100%',

    flexDirection: 'row',

    alignItems: 'center',

    marginTop: 12,
  },

  detailsButton: {
    height: 36,

    paddingHorizontal: 10,

    borderRadius: 18,

    borderWidth: 1,

    flexDirection: 'row',

    alignItems: 'center',

    justifyContent: 'center',
  },

  detailsText: {
    marginLeft: 5,

    fontWeight: '600',
  },

  buyButton: {
    height: 36,

    flex: 1,

    marginLeft: 8,

    paddingHorizontal: 11,

    borderRadius: 18,

    backgroundColor:
      colors.primary,

    flexDirection: 'row',

    alignItems: 'center',

    justifyContent: 'center',
  },

  removeButton: {
    height: 36,

    flex: 1,

    marginLeft: 8,

    paddingHorizontal: 11,

    borderRadius: 18,

    backgroundColor:
      `${colors.error}08`,

    borderWidth: 1,

    borderColor:
      `${colors.error}25`,

    flexDirection: 'row',

    alignItems: 'center',

    justifyContent: 'center',
  },

  removeText: {
    fontWeight: '700',

    marginRight: 5,
  },

  buyText: {
    fontWeight: '700',

    marginRight: 5,
  },

  /* ==========================================================================
     Expanded details
     IMPORTANT:
     No separate card background/border/radius.
     It belongs to the same parent card.
  ========================================================================== */

  expandedSection: {
    width: '100%',

    borderTopWidth:
      StyleSheet.hairlineWidth,

    marginTop: 12,

    paddingTop: 13,

    paddingHorizontal: 4,

    paddingBottom: 3,

    overflow: 'hidden',
  },

  expandedDivider: {
    height: 0,

    marginBottom: 0,
  },

  expandedHeadingRow: {
    flexDirection: 'row',

    alignItems: 'center',

    marginBottom: 8,
  },

  expandedHeadingIcon: {
    width: 36,

    height: 36,

    borderRadius: 12,

    backgroundColor:
      `${colors.primary}0C`,

    alignItems: 'center',

    justifyContent: 'center',
  },

  expandedHeadingContent: {
    flex: 1,

    marginLeft: 9,
  },

  descriptionBox: {
    padding: 12,

    borderRadius: 14,

    backgroundColor:
      `${colors.primary}07`,

    marginBottom: 12,
  },

  descriptionText: {
    lineHeight: 20,
  },

  infoGrid: {
    flexDirection: 'row',

    flexWrap: 'wrap',

    marginHorizontal: -4,
  },

  infoItem: {
    width: '50%',

    paddingHorizontal: 4,

    marginBottom: 8,

    flexDirection: 'row',

    alignItems: 'center',
  },

  infoIcon: {
    width: 34,

    height: 34,

    borderRadius: 11,

    backgroundColor:
      `${colors.primary}0C`,

    alignItems: 'center',

    justifyContent: 'center',
  },

  infoTextContainer: {
    flex: 1,

    marginLeft: 7,
  },

  infoValue: {
    marginTop: 2,

    fontWeight: '600',
  },

  collapseButton: {
    alignSelf: 'center',

    flexDirection: 'row',

    alignItems: 'center',

    paddingHorizontal: 12,

    paddingVertical: 6,

    marginTop: 3,

    borderRadius: 16,

    backgroundColor:
      `${colors.primary}08`,
  },

  collapseText: {
    fontWeight: '600',

    marginRight: 3,
  },
});