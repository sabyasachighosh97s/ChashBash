import React, {
  memo,
  useEffect,
  useState,
} from 'react';

import {
  Modal,
  StyleSheet,
  TouchableOpacity,
  View,
} from 'react-native';

import {
  Headline,
  Paragraph,
} from '@components/ui';

import AppIcon from '@components/AppIcon/AppIcon';

import useThemeMode from '@hook/useThemeMode';
import colors from '@themes/colors';

import {InputItem} from './InputItemCard';

type Props = {
  visible: boolean;

  item: InputItem | null;

  initialQuantity?: number;

  onClose: () => void;

  onAdd: (
    item: InputItem,
    quantity: number,
  ) => void;
};

const MIN_QUANTITY = 1;

const InputQuantityBottomSheet =
  ({
    visible,
    item,
    initialQuantity = MIN_QUANTITY,
    onClose,
    onAdd,
  }: Props) => {
    const {theme} =
      useThemeMode();

    const [
      quantity,
      setQuantity,
    ] = useState(
      initialQuantity,
    );

    useEffect(() => {
      if (visible) {
        setQuantity(
          Math.max(
            MIN_QUANTITY,
            initialQuantity,
          ),
        );
      }
    }, [
      visible,
      item?.id,
      item?.fid,
      initialQuantity,
    ]);

    if (!item) {
      return null;
    }

    const productName =
      item.product_name ||
      item.name ||
      'ইনপুট আইটেম';

    const firstPrice =
      item.agri_product_prices?.[0];

    const price =
      firstPrice?.sales_price ??
      firstPrice?.price;

    const unitName =
      firstPrice?.unit
        ?.unit_name ||
      firstPrice?.unit
        ?.unit_sname ||
      '';

    const packageQuantity =
      firstPrice?.quantity;

    const priceText =
      price !== undefined &&
      price !== null
        ? `₹${price}`
        : '';

    const packageText =
      packageQuantity !==
        undefined &&
      packageQuantity !==
        null &&
      packageQuantity !== ''
        ? `${packageQuantity} ${unitName}`.trim()
        : unitName;

    const decreaseQuantity =
      () => {
        setQuantity(
          current =>
            Math.max(
              MIN_QUANTITY,
              current - 1,
            ),
        );
      };

    const increaseQuantity =
      () => {
        setQuantity(
          current =>
            current + 1,
        );
      };

    return (
      <Modal
        visible={visible}
        transparent
        animationType="slide"
        onRequestClose={
          onClose
        }>

        <View
          style={
            styles.overlay
          }>

          <TouchableOpacity
            activeOpacity={1}
            onPress={onClose}
            style={
              styles.backdrop
            }
          />

          <View
            style={[
              styles.sheet,
              {
                backgroundColor:
                  theme.colors
                    .surface ??
                  colors.surface,
              },
            ]}>

            <View
              style={
                styles.handle
              }
            />

            {/* Header */}

            <View
              style={
                styles.header
              }>

              <View
                style={
                  styles.headerText
                }>

                <Headline
                  size="md"
                  textColor={
                    theme.colors
                      .text ??
                    colors.text
                  }>
                  কতটি নিতে চান?
                </Headline>

              

              </View>

              <TouchableOpacity
                activeOpacity={0.8}
                onPress={onClose}
                style={
                  styles.closeButton
                }>

                <AppIcon
                  type="MaterialIcons"
                  name="close"
                  size={21}
                  color={
                    colors.subText
                  }
                />

              </TouchableOpacity>

            </View>

            {/* Product */}

            <View
              style={
                styles.productBox
              }>

              <View
                style={
                  styles.productIcon
                }>

                <AppIcon
                  type="MaterialIcons"
                  name="inventory-2"
                  size={24}
                  color={
                    colors.primary
                  }
                />

              </View>

              <View
                style={
                  styles.productInfo
                }>

                <Headline
                  size="sm"
                  numberOfLines={2}
                  textColor={
                    theme.colors
                      .text ??
                    colors.text
                  }>
                  {productName}
                </Headline>

                <View
                  style={
                    styles.meta
                  }>

                  {priceText ? (
                    <Paragraph
                      size="xs"
                      textColor={
                        colors.primary
                      }
                      style={
                        styles.price
                      }>
                      {priceText}
                    </Paragraph>
                  ) : null}

                  {packageText ? (
                    <Paragraph
                      size="xs"
                      textColor={
                        colors.subText
                      }>
                      / {packageText}
                    </Paragraph>
                  ) : null}

                </View>

              </View>

            </View>

            {/* Quantity */}

            <Paragraph
              size="sm"
              textColor={
                theme.colors.text ??
                colors.text
              }
              style={
                styles.quantityLabel
              }>
              পরিমাণ
            </Paragraph>

            <View
              style={
                styles.quantityRow
              }>

              <TouchableOpacity
                activeOpacity={0.8}
                disabled={
                  quantity <=
                  MIN_QUANTITY
                }
                onPress={
                  decreaseQuantity
                }
                style={[
                  styles.quantityButton,
                  quantity <=
                    MIN_QUANTITY &&
                    styles.disabledButton,
                ]}>

                <AppIcon
                  type="MaterialIcons"
                  name="remove"
                  size={24}
                  color={
                    quantity <=
                    MIN_QUANTITY
                      ? colors.disabled
                      : colors.primary
                  }
                />

              </TouchableOpacity>

              <View
                style={
                  styles.quantityValue
                }>

                <Headline
                  size="lg"
                  textColor={
                    theme.colors.text ??
                    colors.text
                  }>
                  {quantity}
                </Headline>

                <Paragraph
                  size="xs"
                  textColor={
                    colors.subText
                  }>
                  টি
                </Paragraph>

              </View>

              <TouchableOpacity
                activeOpacity={0.8}
                onPress={
                  increaseQuantity
                }
                style={
                  styles.quantityButton
                }>

                <AppIcon
                  type="MaterialIcons"
                  name="add"
                  size={24}
                  color={
                    colors.primary
                  }
                />

              </TouchableOpacity>

            </View>

            {/* Notice */}

            <View
              style={
                styles.notice
              }>

              <AppIcon
                type="MaterialIcons"
                name="info-outline"
                size={18}
                color={
                  colors.info
                }
              />

              <Paragraph
                size="xs"
                textColor={
                  colors.subText
                }
                style={
                  styles.noticeText
                }>
                এটি কোনো অনলাইন পেমেন্ট নয়।
                শুধু আপনার চাহিদার তালিকায়
                যোগ হবে।
              </Paragraph>

            </View>

            {/* Add */}

            <TouchableOpacity
              activeOpacity={0.85}
              onPress={() =>
                onAdd(
                  item,
                  quantity,
                )
              }
              style={
                styles.addButton
              }>

              <AppIcon
                type="MaterialIcons"
                name="playlist-add-check"
                size={21}
                color={
                  colors.textLight
                }
              />

              <Paragraph
                size="sm"
                textColor={
                  colors.textLight
                }
                style={
                  styles.addText
                }>
                {initialQuantity > 1
                  ? 'চাহিদা আপডেট করুন'
                  : 'আমার চাহিদায় যোগ করুন'}
              </Paragraph>

            </TouchableOpacity>

          </View>
        </View>

      </Modal>
    );
  };

export default memo(
  InputQuantityBottomSheet,
);

const styles =
  StyleSheet.create({
    overlay: {
      flex: 1,

      justifyContent:
        'flex-end',
    },

    backdrop: {
      ...StyleSheet.absoluteFill,

      backgroundColor:
        colors.backdrop,
    },

    sheet: {
      width: '100%',

      borderTopLeftRadius: 28,
      borderTopRightRadius: 28,

      paddingHorizontal: 20,

      paddingTop: 9,
      paddingBottom: 24,

      elevation: 12,
    },

    handle: {
      width: 42,
      height: 4,

      borderRadius: 2,

      alignSelf: 'center',

      backgroundColor:
        colors.border,

      marginBottom: 16,
    },

    header: {
      flexDirection: 'row',

      alignItems: 'center',

      marginBottom: 16,
    },

    headerText: {
      flex: 1,
    },

    closeButton: {
      width: 38,
      height: 38,

      borderRadius: 19,

      backgroundColor:
        colors.background,

      alignItems: 'center',
      justifyContent: 'center',
    },

    productBox: {
      minHeight: 72,

      borderRadius: 17,

      padding: 10,

      borderWidth: 1,

      borderColor:
        colors.border,

      backgroundColor:
        `${colors.primary}06`,

      flexDirection: 'row',

      alignItems: 'center',
    },

    productIcon: {
      width: 50,
      height: 50,

      borderRadius: 15,

      backgroundColor:
        `${colors.primary}10`,

      alignItems: 'center',
      justifyContent: 'center',
    },

    productInfo: {
      flex: 1,

      marginLeft: 10,
    },

    meta: {
      flexDirection: 'row',

      alignItems: 'baseline',

     
    },

    price: {
      fontWeight: '700',

      marginRight: 3,
    },

    quantityLabel: {
      marginTop: 18,

      marginBottom: 9,

      fontWeight: '700',
    },

    quantityRow: {
      flexDirection: 'row',

      alignItems: 'center',

      justifyContent:
        'center',
    },

    quantityButton: {
      width: 50,
      height: 50,

      borderRadius: 16,

      borderWidth: 1,

      borderColor:
        `${colors.primary}35`,

      backgroundColor:
        `${colors.primary}08`,

      alignItems: 'center',
      justifyContent: 'center',
    },

    disabledButton: {
      opacity: 0.45,
    },

    quantityValue: {
      width: 80,

      alignItems: 'center',
      justifyContent: 'center',
    },

    notice: {
      flexDirection: 'row',

      alignItems: 'center',

      marginTop: 18,

      padding: 10,

      borderRadius: 14,

      backgroundColor:
        `${colors.info}08`,
    },

    noticeText: {
      flex: 1,

      marginLeft: 8,

      lineHeight: 18,
    },

    addButton: {
      height: 50,

      borderRadius: 17,

      marginTop: 15,

      backgroundColor:
        colors.primary,

      flexDirection: 'row',

      alignItems: 'center',
      justifyContent: 'center',
    },

    addText: {
      marginLeft: 7,

      fontWeight: '700',
    },
  });