import React, {
  useCallback,
  useEffect,
  useMemo,
  useState,
} from 'react';

import {
  FlatList,
  StyleSheet,
  TouchableOpacity,
  View,
} from 'react-native';

import {
  Container,
  Headline,
  Paragraph,
} from '@components/ui';

import AppIcon from '@components/AppIcon/AppIcon';
import PlantLoader from '@components/common/PlantLoader';
import useThemeMode from '@hook/useThemeMode';
import colors from '@themes/colors';
import GuestAccessModal, {
  useGuestAccess,
} from '@components/common/GuestAccess';
import CustomHeader from '@components/Header/CustomHeader';

import {
  useNavigation,
} from '@react-navigation/native';

import InputItemCard, {
  InputItem,
} from '@components/inputOutput/InputItemCard';

import InputQuantityBottomSheet from '@components/inputOutput/InputQuantityBottomSheet';

import CropFilterModal from '@screens/POP/CropFilterModal';

import InputCategoryFilter, {
  InputFilterItem,
} from '@components/inputOutput/InputCategoryFilter';

import InputFilterModal from '@components/inputOutput/InputFilterModal';

import InputSubCategoryFilter from '@components/inputOutput/InputSubCategoryFilter';

import Pagination from '@components/common/Pagination/Pagination';

import SideFab from '@components/AppFab/SideFab';
import { FabAction } from '@navigation/fab/fabTypes';

/* ==========================================================================
   Types
========================================================================== */

export type SelectedInputItem = {
  item: InputItem;
  quantity: number;
};

/* ==========================================================================
   Categories
========================================================================== */

const DEMO_CATEGORIES:
  InputFilterItem[] = [
  {
    value: 'all',
    label: 'সব',
  },
  {
    value: 'fertilizer',
    label: 'সার',
  },
  {
    value: 'seed',
    label: 'বীজ',
  },
  {
    value: 'pesticide',
    label: 'কীটনাশক',
  },
  {
    value: 'equipment',
    label: 'কৃষি সরঞ্জাম',
  },
];

/* ==========================================================================
   Sub Categories
========================================================================== */

const DEMO_SUB_CATEGORIES:
  Record<
    string,
    InputFilterItem[]
  > = {
  fertilizer: [
    {
      value:
        'organic-fertilizer',
      label: 'জৈব সার',
    },
    {
      value:
        'chemical-fertilizer',
      label: 'রাসায়নিক সার',
    },
  ],

  seed: [
    {
      value: 'paddy-seed',
      label: 'ধানের বীজ',
    },
    {
      value:
        'vegetable-seed',
      label: 'সবজি বীজ',
    },
  ],

  pesticide: [
    {
      value: 'insecticide',
      label: 'কীটনাশক',
    },
    {
      value: 'fungicide',
      label: 'ছত্রাকনাশক',
    },
  ],

  equipment: [
    {
      value: 'sprayer',
      label: 'স্প্রে মেশিন',
    },
    {
      value: 'farm-tools',
      label: 'কৃষি যন্ত্রপাতি',
    },
  ],
};

const SelectedInputListAction: FabAction = {
  id: 'selected-input-list',
  icon: 'playlist-check',
  label: 'ইনপুট আইটেম লিস্ট',
  color: colors.primary,
  route: 'InputRequest',
};

/* ==========================================================================
   Demo Items
========================================================================== */

const DEMO_INPUT_ITEMS:
  InputItem[] = [
  {
    id: 'fert-001',
    fid: 'fert-001',
    product_name:
      'ভার্মি কম্পোস্ট',
    product_code:
      'ORG-FERT-001',
    description:
      'মাটির উর্বরতা বৃদ্ধি করতে সহায়ক জৈব সার।',
    category:
      'fertilizer',
    sub_category:
      'organic-fertilizer',
    agri_product_prices: [
      {
        prod_price_id:
          'price-fert-001',
        quantity: 1,
        price: 350,
        unit: {
          unit_name: 'কেজি',
          unit_sname: 'Kg',
          fid: 'kg',
        },
      },
    ],
  },

  {
    id: 'fert-002',
    fid: 'fert-002',
    product_name:
      'ইউরিয়া সার',
    product_code:
      'CHEM-FERT-001',
    description:
      'ফসলের দ্রুত বৃদ্ধির জন্য ব্যবহৃত নাইট্রোজেন সার।',
    category:
      'fertilizer',
    sub_category:
      'chemical-fertilizer',
    agri_product_prices: [
      {
        prod_price_id:
          'price-fert-002',
        quantity: 50,
        price: 1350,
        unit: {
          unit_name: 'কেজি',
          unit_sname: 'Kg',
          fid: 'kg',
        },
      },
    ],
  },

  {
    id: 'fert-003',
    fid: 'fert-003',
    product_name:
      'সরিষার খৈল',
    product_code:
      'ORG-FERT-002',
    description:
      'জৈব উপাদানে সমৃদ্ধ প্রাকৃতিক সার।',
    category:
      'fertilizer',
    sub_category:
      'organic-fertilizer',
    agri_product_prices: [
      {
        prod_price_id:
          'price-fert-003',
        quantity: 1,
        price: 80,
        unit: {
          unit_name: 'কেজি',
          unit_sname: 'Kg',
          fid: 'kg',
        },
      },
    ],
  },

  {
    id: 'seed-001',
    fid: 'seed-001',
    product_name:
      'উন্নত জাতের ধানের বীজ',
    product_code:
      'PADDY-SEED-001',
    description:
      'উচ্চ ফলনশীল ধানের জন্য উন্নত মানের বীজ।',
    category: 'seed',
    sub_category:
      'paddy-seed',
    agri_product_prices: [
      {
        prod_price_id:
          'price-seed-001',
        quantity: 1,
        price: 120,
        unit: {
          unit_name: 'কেজি',
          unit_sname: 'Kg',
          fid: 'kg',
        },
      },
    ],
  },

  {
    id: 'seed-002',
    fid: 'seed-002',
    product_name:
      'টমেটো বীজ',
    product_code:
      'VEG-SEED-001',
    description:
      'উন্নত জাতের টমেটো চাষের জন্য উপযোগী।',
    category: 'seed',
    sub_category:
      'vegetable-seed',
    agri_product_prices: [
      {
        prod_price_id:
          'price-seed-002',
        quantity: 10,
        price: 95,
        unit: {
          unit_name: 'গ্রাম',
          unit_sname: 'g',
          fid: 'g',
        },
      },
    ],
  },

  {
    id: 'seed-003',
    fid: 'seed-003',
    product_name:
      'লাউ বীজ',
    product_code:
      'VEG-SEED-002',
    description:
      'সবজি চাষের জন্য মানসম্মত লাউ বীজ।',
    category: 'seed',
    sub_category:
      'vegetable-seed',
    agri_product_prices: [
      {
        prod_price_id:
          'price-seed-003',
        quantity: 10,
        price: 75,
        unit: {
          unit_name: 'গ্রাম',
          unit_sname: 'g',
          fid: 'g',
        },
      },
    ],
  },

  {
    id: 'pest-001',
    fid: 'pest-001',
    product_name:
      'নিম তেল',
    product_code:
      'INSECT-001',
    description:
      'প্রাকৃতিকভাবে বিভিন্ন ক্ষতিকর পোকামাকড় নিয়ন্ত্রণে সহায়ক।',
    category:
      'pesticide',
    sub_category:
      'insecticide',
    agri_product_prices: [
      {
        prod_price_id:
          'price-pest-001',
        quantity: 1,
        price: 280,
        unit: {
          unit_name: 'লিটার',
          unit_sname: 'L',
          fid: 'liter',
        },
      },
    ],
  },

  {
    id: 'pest-002',
    fid: 'pest-002',
    product_name:
      'ছত্রাকনাশক',
    product_code:
      'FUNG-001',
    description:
      'ফসলের বিভিন্ন ছত্রাকজনিত সমস্যা নিয়ন্ত্রণে ব্যবহৃত হয়।',
    category:
      'pesticide',
    sub_category:
      'fungicide',
    agri_product_prices: [
      {
        prod_price_id:
          'price-pest-002',
        quantity: 500,
        price: 420,
        unit: {
          unit_name:
            'মিলিলিটার',
          unit_sname: 'ml',
          fid: 'ml',
        },
      },
    ],
  },

  {
    id: 'equipment-001',
    fid: 'equipment-001',
    product_name:
      'ম্যানুয়াল স্প্রে মেশিন',
    product_code:
      'SPRAYER-001',
    description:
      'ছোট ও মাঝারি জমিতে কীটনাশক বা তরল সার প্রয়োগের জন্য।',
    category:
      'equipment',
    sub_category:
      'sprayer',
    agri_product_prices: [
      {
        prod_price_id:
          'price-equipment-001',
        quantity: 1,
        price: 950,
        unit: {
          unit_name: 'পিস',
          unit_sname: 'Pc',
          fid: 'piece',
        },
      },
    ],
  },

  {
    id: 'equipment-002',
    fid: 'equipment-002',
    product_name:
      'হ্যান্ড উইডার',
    product_code:
      'FARM-TOOLS-001',
    description:
      'জমির আগাছা পরিষ্কার করার জন্য সহজ ও কার্যকর কৃষি যন্ত্র।',
    category:
      'equipment',
    sub_category:
      'farm-tools',
    agri_product_prices: [
      {
        prod_price_id:
          'price-equipment-002',
        quantity: 1,
        price: 450,
        unit: {
          unit_name: 'পিস',
          unit_sname: 'Pc',
          fid: 'piece',
        },
      },
    ],
  },

  {
    id: 'fert-004',
    fid: 'fert-004',
    product_name:
      'কম্পোস্ট সার',
    product_code:
      'ORG-FERT-003',
    description:
      'জৈব উপাদান সমৃদ্ধ মাটির গুণমান উন্নতকারী সার।',
    category:
      'fertilizer',
    sub_category:
      'organic-fertilizer',
    agri_product_prices: [
      {
        prod_price_id:
          'price-fert-004',
        quantity: 5,
        price: 300,
        unit: {
          unit_name: 'কেজি',
          unit_sname: 'Kg',
          fid: 'kg',
        },
      },
    ],
  },

  {
    id: 'seed-004',
    fid: 'seed-004',
    product_name:
      'বেগুন বীজ',
    product_code:
      'VEG-SEED-003',
    description:
      'উন্নত জাতের বেগুন চাষের জন্য মানসম্মত বীজ।',
    category: 'seed',
    sub_category:
      'vegetable-seed',
    agri_product_prices: [
      {
        prod_price_id:
          'price-seed-004',
        quantity: 10,
        price: 85,
        unit: {
          unit_name: 'গ্রাম',
          unit_sname: 'g',
          fid: 'g',
        },
      },
    ],
  },
];

/* ==========================================================================
   Screen
========================================================================== */

const InputOutputScreen =
  () => {
    const {theme} =
      useThemeMode();

    const navigation =
      useNavigation<any>();

        const {
    isGuest,
    visible,
    openGuestAccess,
    closeGuestAccess,
    goToRegistration,
  } = useGuestAccess();

    /* ----------------------------------------------------------------------
       Filter
    ---------------------------------------------------------------------- */

    const [
      selectedCategory,
      setSelectedCategory,
    ] = useState('all');

    const [
      selectedSubCategory,
      setSelectedSubCategory,
    ] = useState('all');

    const [
      filterVisible,
      setFilterVisible,
    ] = useState(false);

    /* ----------------------------------------------------------------------
       Pagination
    ---------------------------------------------------------------------- */

    const [
      currentPage,
      setCurrentPage,
    ] = useState(1);

    const ITEMS_PER_PAGE = 10;

    /* ----------------------------------------------------------------------
       Quantity
    ---------------------------------------------------------------------- */

    const [
      quantitySheetVisible,
      setQuantitySheetVisible,
    ] = useState(false);

    const [
      quantityItem,
      setQuantityItem,
    ] = useState<InputItem | null>(
      null,
    );

    /* ----------------------------------------------------------------------
       Selected request
    ---------------------------------------------------------------------- */

    const [
      selectedInputItems,
      setSelectedInputItems,
    ] = useState<
      SelectedInputItem[]
    >([]);

    const [
      loading,
      setLoading,
    ] = useState(false);

    /* ======================================================================
       Subcategories
    ====================================================================== */

    const subCategories =
      useMemo(() => {
        if (
          selectedCategory ===
          'all'
        ) {
          return [];
        }

        return (
          DEMO_SUB_CATEGORIES[
            selectedCategory
          ] ?? []
        );
      }, [
        selectedCategory,
      ]);

    /* ======================================================================
       Filter
    ====================================================================== */

    const filteredItems =
      useMemo(() => {
        if (
          selectedCategory ===
          'all'
        ) {
          return DEMO_INPUT_ITEMS;
        }

        return DEMO_INPUT_ITEMS.filter(
          item => {
            if (
              item.category !==
              selectedCategory
            ) {
              return false;
            }

            if (
              selectedSubCategory ===
              'all'
            ) {
              return true;
            }

            return (
              item.sub_category ===
              selectedSubCategory
            );
          },
        );
      }, [
        selectedCategory,
        selectedSubCategory,
      ]);

    /* ======================================================================
       Pagination
    ====================================================================== */

    const totalPages =
      Math.ceil(
        filteredItems.length /
          ITEMS_PER_PAGE,
      );

    const paginatedItems =
      useMemo(() => {
        const start =
          (currentPage - 1) *
          ITEMS_PER_PAGE;

        return filteredItems.slice(
          start,
          start +
            ITEMS_PER_PAGE,
        );
      }, [
        filteredItems,
        currentPage,
      ]);

    /* ======================================================================
       Category
    ====================================================================== */

    const handleCategoryChange =
      useCallback(
        (item: InputFilterItem) => {
          const value =
            String(item.value);

          setSelectedCategory(
            value,
          );

          setSelectedSubCategory(
            'all',
          );

          setCurrentPage(1);

          setFilterVisible(false);
        },
        [],
      );

    /* ======================================================================
       Subcategory
    ====================================================================== */

    const handleSubCategoryChange =
      useCallback(
        (item: InputFilterItem) => {
          const value =
            String(item.value);

          setSelectedSubCategory(
            value,
          );

          setCurrentPage(1);
        },
        [],
      );

    /* ======================================================================
       Open quantity
    ====================================================================== */

    const handleBuy =
      useCallback(
        (item: InputItem) => {
          setQuantityItem(item);

          setQuantitySheetVisible(
            true,
          );
        },
        [],
      );

    /* ======================================================================
       Remove from selected
    ====================================================================== */

    const handleRemove =
      useCallback(
        (item: InputItem) => {
          const itemId =
            item.id ?? item.fid;

          setSelectedInputItems(
            current =>
              current.filter(
                selected =>
                  (selected.item.id ??
                    selected.item.fid) !==
                  itemId,
              ),
          );
        },
        [],
      );

    /* ======================================================================
       Add / update request
    ====================================================================== */

    const handleAddToRequest =
      useCallback(
        (
          item: InputItem,
          quantity: number,
        ) => {
          const itemId =
            item.id ?? item.fid;

          setSelectedInputItems(
            current => {
              const existingIndex =
                current.findIndex(
                  selected =>
                    (selected.item.id ??
                      selected.item.fid) ===
                    itemId,
                );

              if (
                existingIndex ===
                -1
              ) {
                return [
                  ...current,
                  {
                    item,
                    quantity,
                  },
                ];
              }

              const updated =
                [...current];

              updated[
                existingIndex
              ] = {
                item,
                quantity,
              };

              return updated;
            },
          );

          setQuantitySheetVisible(
            false,
          );

          setQuantityItem(null);
        },
        [],
      );

    /* ======================================================================
       Selected helper
    ====================================================================== */

    const isItemSelected =
      useCallback(
        (item: InputItem) => {
          const id =
            item.id ?? item.fid;

          return selectedInputItems.some(
            selected =>
              (selected.item.id ??
                selected.item.fid) ===
              id,
          );
        },
        [selectedInputItems],
      );

    /* ======================================================================
       Demo loading
    ====================================================================== */

    useEffect(() => {
      setLoading(true);

      const timer =
        setTimeout(() => {
          setLoading(false);
        }, 1800);

      return () =>
        clearTimeout(timer);
    }, []);

    /* ======================================================================
       Render
    ====================================================================== */

    const renderItem =
      useCallback(
        ({
          item,
        }: {
          item: InputItem;
        }) => (
      <InputItemCard
  item={item}
  selected={isItemSelected(item)}
  onBuy={(item) => {
    if (isGuest) {
      openGuestAccess();
      return;
    }

    handleBuy(item);
  }}
  onRemove={handleRemove}
/>
        ),
        [
         isItemSelected,
  handleBuy,
  handleRemove,
  isGuest,
  openGuestAccess,
        ],
      );

    const selectedCount =
      selectedInputItems.length;

    const totalSelectedQuantity =
      selectedInputItems.reduce(
        (total, item) =>
          total + item.quantity,
        0,
      );

    const resultText =
      `${filteredItems.length}টি`;

    /* ======================================================================
       UI
    ====================================================================== */

    return (
      <Container
        backgroundColor={
          theme.colors.background
        }
        style={
          styles.container
        }>

        {/* ================================================================
            HEADER
        ================================================================= */}

        <CustomHeader
          showFilter
          onFilterPress={() =>
            setFilterVisible(true)
          }
        />

        {/* ================================================================
            Main
        ================================================================= */}

        <View
          style={
            styles.content
          }>

          {/* --------------------------------------------------------------
              Subcategory only
          --------------------------------------------------------------- */}

          {subCategories.length >
            0 && (
            <InputSubCategoryFilter
              items={
                subCategories
              }
              selectedValue={
                selectedSubCategory
              }
              onSelect={
                handleSubCategoryChange
              }
            />
          )}

         

          {/* --------------------------------------------------------------
              Products
          --------------------------------------------------------------- */}

          {loading ? (
            <View
              style={
                styles.loadingContainer
              }>

             <PlantLoader />

            </View>
          ) : (
            <FlatList
              data={
                paginatedItems
              }
              renderItem={
                renderItem
              }
              keyExtractor={item =>
                String(
                  item.id ??
                    item.fid,
                )
              }
              showsVerticalScrollIndicator={
                false
              }
              contentContainerStyle={
                styles.listContent
              }
              ListEmptyComponent={
                <View
                  style={
                    styles.emptyContainer
                  }>

                  <AppIcon
                    type="MaterialIcons"
                    name="inventory-2"
                    size={38}
                    color={
                      colors.primary
                    }
                  />

                  <Headline
                    size="sm"
                    textColor={
                      theme.colors.text
                    }
                    style={
                      styles.emptyTitle
                    }>
                    কোনো উপকরণ পাওয়া যায়নি
                  </Headline>

                  <Paragraph
                    size="xs"
                    textColor={
                      colors.subText
                    }>
                    অন্য ফিল্টার নির্বাচন করুন
                  </Paragraph>

                </View>
              }
            />
          )}

          {/* --------------------------------------------------------------
              Fixed Pagination
          --------------------------------------------------------------- */}

         {totalPages > 1 && (
  <View
    style={[
      styles.fixedPagination,
      selectedCount > 0 &&
        styles.fixedPaginationWithRequest,
    ]}>
    <Pagination
      currentPage={
        currentPage
      }
      totalPages={
        totalPages
      }
      onPageChange={
        setCurrentPage
      }
    />
  </View>
)}
        </View>

        {/* ================================================================
            Selected Request Bar
        ================================================================= */}

        {selectedCount > 0 && (
          <View
            style={
              styles.requestBar
            }>

            {/* Left */}

            <View
              style={
                styles.requestInfo
              }>

              <View
                style={
                  styles.requestIcon
                }>

                <AppIcon
                  type="MaterialIcons"
                  name="playlist-add-check"
                  size={23}
                  color={
                    colors.textLight
                  }
                />

                <View
                  style={
                    styles.requestCount
                  }>

                  <Paragraph
                    size="xs"
                    textColor={
                      colors.primary
                    }
                    style={
                      styles.requestCountText
                    }>
                    {selectedCount}
                  </Paragraph>

                </View>

              </View>

              <View
                style={
                  styles.requestText
                }>

                <Headline
                  size="xs"
                  textColor={
                    colors.textLight
                  }>
                  আমার চাহিদা
                </Headline>

            <View style={styles.requestMetaRow}>

  <Paragraph
    size="xs"
    textColor={
      'rgba(255,255,255,0.78)'
    }
    style={styles.requestMetaText}>
    {selectedCount}টি
  </Paragraph>

  <Paragraph
    size="xs"
    textColor={
      'rgba(255,255,255,0.55)'
    }
    style={styles.requestMetaDot}>
    •
  </Paragraph>

  <Paragraph
    size="xs"
    textColor={
      'rgba(255,255,255,0.78)'
    }
    style={styles.requestMetaText}>
    {totalSelectedQuantity}টি
  </Paragraph>

</View>

              </View>

            </View>

            {/* View request */}

            <TouchableOpacity
              activeOpacity={0.85}
              onPress={() =>
                navigation.navigate(
                  'InputRequest',
                  {
                    selectedItems:
                      selectedInputItems,
                  },
                )
              }
              style={
                styles.viewRequestButton
              }>

              <Paragraph
                size="xs"
                textColor={
                  colors.primary
                }
                style={
                  styles.viewRequestText
                }>
                দেখুন
              </Paragraph>

              <AppIcon
                type="MaterialIcons"
                name="arrow-forward"
                size={17}
                color={
                  colors.primary
                }
              />

            </TouchableOpacity>

          </View>
        )}

        {/* ================================================================
            Quantity Bottom Sheet
        ================================================================= */}

        <InputQuantityBottomSheet
          visible={
            quantitySheetVisible
          }
          item={
            quantityItem
          }
          initialQuantity={
            quantityItem
              ? (
                  selectedInputItems.find(
                    selected =>
                      (selected.item.id ??
                        selected.item.fid) ===
                      (quantityItem.id ??
                        quantityItem.fid),
                  )?.quantity ??
                  1
                )
              : 1
          }
          onClose={() => {
            setQuantitySheetVisible(
              false,
            );

            setQuantityItem(null);
          }}
          onAdd={
            handleAddToRequest
          }
        />

        {/* ================================================================
            Category Filter Modal
        ================================================================= */}

   <CropFilterModal
  visible={filterVisible}
  onClose={() =>
    setFilterVisible(false)
  }
  selectedCrop={selectedCategory}
  onSelect={category => {
    const selectedItem =
      DEMO_CATEGORIES.find(
        item =>
          String(item.value) ===
          String(category),
      );

    if (selectedItem) {
      handleCategoryChange(selectedItem);
    }
  }}
  cropList={DEMO_CATEGORIES.map(item => ({
    value: String(item.value),
    label: item.label,
  }))}
/>

<SideFab
  actions={[SelectedInputListAction]}
  bottom={
    selectedCount > 0
      ? 170
      : 100
  }
  onActionPress={action => {
    if (
      action.id ===
      'selected-input-list'
    ) {
      navigation.navigate(
        'MyInputRequests',
        {
          selectedItems:
            selectedInputItems,
        },
      );
    }
  }}
/>
<GuestAccessModal
  visible={visible}
  onClose={closeGuestAccess}
  onRegister={goToRegistration}
/>
      </Container>
    );
  };

export default InputOutputScreen;

/* ==========================================================================
   Styles
========================================================================== */

const styles =
  StyleSheet.create({
    container: {
      flex: 1,
    },

    content: {
      flex: 1,
      paddingHorizontal: 14,
      marginTop:10
    },

    resultHeader: {
      minHeight: 38,

      flexDirection: 'row',

      alignItems: 'center',

      justifyContent:
        'space-between',

      marginBottom: 8,
    },

    resultBadge: {
      minWidth: 48,

      height: 28,

      borderRadius: 14,

      paddingHorizontal: 10,

      backgroundColor:
        `${colors.primary}10`,

      alignItems: 'center',

      justifyContent: 'center',
    },

    resultBadgeText: {
      fontWeight: '700',
    },

    listContent: {
      paddingTop: 1,

      paddingBottom: 100,
    },

    loadingContainer: {
      flex: 1,

      alignItems: 'center',

      justifyContent: 'center',

      paddingBottom: 60,
    },

    emptyContainer: {
      flex: 1,

      alignItems: 'center',

      justifyContent: 'center',

      paddingTop: 70,
    },

    emptyTitle: {
      marginTop: 12,

      marginBottom: 4,
    },

    /* ======================================================================
       Fixed Pagination
    ====================================================================== */

    fixedPagination: {
      position: 'absolute',

      left: 14,

      right: 14,

      bottom: 10,

      backgroundColor:
        colors.surface,

      borderRadius: 18,

      elevation: 8,

      shadowOffset: {
        width: 0,
        height: 3,
      },

      shadowOpacity: 0.12,

      shadowRadius: 8,
    },

    fixedPaginationWithRequest: {
      bottom: 88,
    },

    /* ======================================================================
       Request bar
    ====================================================================== */

    requestBar: {
      position: 'absolute',

      left: 12,

      right: 12,

      bottom: 10,

      minHeight: 68,

      borderRadius: 21,

      paddingHorizontal: 10,

      backgroundColor:
        colors.primary,

      flexDirection: 'row',

      alignItems: 'center',

      elevation: 10,

      shadowOffset: {
        width: 0,
        height: 5,
      },

      shadowOpacity: 0.18,

      shadowRadius: 10,
    },

  requestInfo: {
  flex: 1,

  flexDirection: 'row',

  alignItems: 'center',

  minWidth: 0,
},
    requestIcon: {
  width: 45,

  height: 45,

  borderRadius: 15,

  backgroundColor:
    'rgba(255,255,255,0.16)',

  alignItems: 'center',

  justifyContent: 'center',

  position: 'relative',

  marginRight: 9,
},

    requestCount: {
  position: 'absolute',

  top: -4,

  right: -4,

  minWidth: 21,

  height: 21,

  borderRadius: 11,

  backgroundColor:
    colors.accent,

  alignItems: 'center',

  justifyContent: 'center',

  paddingHorizontal: 4,
},

    requestCountText: {
      fontWeight: '800',
    },

   requestText: {
  flex: 1,

  minWidth: 0,

  justifyContent: 'center',

  alignItems: 'flex-start',
},

    viewRequestButton: {
      height: 43,

      minWidth: 80,

      borderRadius: 15,

      paddingHorizontal: 12,

      backgroundColor:
        colors.accent,

      flexDirection: 'row',

      alignItems: 'center',

      justifyContent: 'center',
    },

    viewRequestText: {
      fontWeight: '800',

      marginRight: 4,
    },

    /* ======================================================================
       Filter modal
    ====================================================================== */

    filterOverlay: {
      flex: 1,

      justifyContent:
        'flex-start',
    },

    filterBackdrop: {
      ...StyleSheet.absoluteFill,

      backgroundColor:
        'rgba(0,0,0,0.48)',
    },

    filterCard: {
      marginTop: 82,

      marginHorizontal: 14,

      borderRadius: 23,

      padding: 15,

      elevation: 12,
    },

    filterHeader: {
      flexDirection: 'row',

      alignItems: 'center',

      marginBottom: 12,
    },

    filterHeaderIcon: {
      width: 40,

      height: 40,

      borderRadius: 13,

      backgroundColor:
        `${colors.primary}10`,

      alignItems: 'center',

      justifyContent: 'center',
    },

    filterHeaderText: {
      flex: 1,

      marginLeft: 9,
    },

    filterClose: {
      width: 38,

      height: 38,

      borderRadius: 19,

      backgroundColor:
        colors.background,

      alignItems: 'center',

      justifyContent: 'center',
    },

    requestMetaRow: {
  flexDirection: 'row',

  alignItems: 'center',

  marginTop: 2,
},

requestMetaText: {
  lineHeight: 16,

  fontWeight: '500',
},

requestMetaDot: {
  marginHorizontal: 6,

  lineHeight: 16,
},
  });