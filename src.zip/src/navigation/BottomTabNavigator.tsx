import React from 'react';

import { View, TouchableOpacity, Text, StyleSheet } from 'react-native';
import { Card, Container, Headline, Paragraph } from '@components/ui';
import colors from '@themes/colors';
import {
  createBottomTabNavigator,
  BottomTabBarProps,
} from '@react-navigation/bottom-tabs';

import HomeScreen from '@screens/HomeScreen';

const Tab = createBottomTabNavigator();

/*
=====================================
EMPTY SCREENS
=====================================
*/

const EmptyScreen = () => {
  return (
    <View
      style={{
        flex: 1,
        backgroundColor: '#F4F7F1',
      }}
    />
  );
};

const CustomTabBar = ({ state, navigation }: BottomTabBarProps) => {
  return (
    <View style={styles.bottomTabBar}>
      {state.routes.map((route, index) => {
        const isFocused = state.index === index;

        const onPress = () => {
          navigation.navigate(route.name);
        };

        let icon = '🏠';

        if (route.name === 'Fields') {
          icon = '🌾';
        }

        if (route.name === 'Add') {
          icon = '+';
        }

        if (route.name === 'Docs') {
          icon = '📄';
        }

        if (route.name === 'Profile') {
          icon = '👤';
        }

        if (route.name === 'Add') {
          return (
            <TouchableOpacity
              key={route.key}
              activeOpacity={0.9}
              onPress={onPress}
              style={styles.centerButton}
            >
              <Paragraph style={styles.centerButtonText}>{icon}</Paragraph>{' '}
            </TouchableOpacity>
          );
        }

        return (
          <TouchableOpacity
            key={route.key}
            activeOpacity={0.8}
            onPress={onPress}
            style={styles.bottomTabItem}
          >
            <Paragraph
              style={[
                styles.bottomTabIcon,
                {
                  color: isFocused ? colors.accent : colors.textLight,
                },
              ]}
            >
              {icon}
            </Paragraph>

            <Paragraph
              size="xs"
              style={[
                styles.bottomTabText,
                {
                  color: isFocused ? colors.accent : colors.textLight,
                },
              ]}
            >
              {route.name}
            </Paragraph>
          </TouchableOpacity>
        );
      })}
    </View>
  );
};

const BottomTabNavigator = () => {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
      }}
      tabBar={props => <CustomTabBar {...props} />}
    >
      <Tab.Screen name="Home" component={HomeScreen} />

      <Tab.Screen name="Fields" component={EmptyScreen} />

      <Tab.Screen name="Add" component={EmptyScreen} />

      <Tab.Screen name="Docs" component={EmptyScreen} />

      <Tab.Screen name="Profile" component={EmptyScreen} />
    </Tab.Navigator>
  );
};

export default BottomTabNavigator;

const styles = StyleSheet.create({
  bottomTabBar: {
    position: 'absolute',

    bottom: 10,

    left: 18,

    right: 18,

    height: 60,

    backgroundColor: '#21432d',

    borderRadius: 34,

    flexDirection: 'row',

    justifyContent: 'space-around',

    alignItems: 'center',

    shadowColor: '#000',

    shadowOffset: {
      width: 0,
      height: 8,
    },

    shadowOpacity: 0.18,

    shadowRadius: 12,

    elevation: 12,
  },

  bottomTabItem: {
    flex: 1,

    justifyContent: 'center',

    alignItems: 'center',
  },

  bottomTabIcon: {
    fontSize: 18,
  },

  bottomTabText: {
    marginTop: 4,

    fontWeight: '600',
  },

  centerButton: {
    width: 50,

    height: 50,

    borderRadius: 28,

    backgroundColor: '#A4E45F',

    justifyContent: 'center',

    alignItems: 'center',

    marginTop: -25,

    borderWidth: 5,

    borderColor: '#173522',

    shadowColor: '#000',

    shadowOffset: {
      width: 0,
      height: 4,
    },

    shadowOpacity: 0.2,

    shadowRadius: 8,

    elevation: 10,
  },

  centerButtonText: {
    fontSize: 30,

    color: colors.bottomBar,

    fontWeight: '900',
  },
});
