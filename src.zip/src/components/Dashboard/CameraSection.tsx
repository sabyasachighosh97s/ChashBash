import React from 'react';

import { Image, StyleSheet, Text, TouchableOpacity, View } from 'react-native';

import {
  Container,
  Card,
  Button,
  Icon,
  Headline,
  Paragraph,
} from '@components/ui';

type Props = {
  data: {
    title: string;

    description: string;

    buttonText: string;
  };
};

const CameraSection = ({ data }: Props) => {
  return (
    <>
      <Headline>{data.title}</Headline>

      <Paragraph
        size="base"
        style={{
          textAlign: 'left',
        }}
      >
        {data.description}
      </Paragraph>

      <Card
        // key={item.label}
        variant="contained"
        style={
          [
            // styles.cameraContainer,
            // {
            //   backgroundColor: theme.colors.background,
            // },
          ]
        }
      >
        <View style={styles.cameraTopRow}>
          <Card style={styles.cameraPreviewCard}>
            <Image
              source={require('../../assets/images/leaf_scan.png')}
              style={styles.liveCameraImage}
              resizeMode="contain"
            />

            <Paragraph
              size="sm"
              style={{
                textAlign: 'center',
                fontWeight: '700',
              }}
            >
              এইভাবে ছবি তুলুন
            </Paragraph>
            <Paragraph
              size="xs"
              style={{
                textAlign: 'center',
              }}
            >
              ভালো আলোতে পাতাটি পরিষ্কারভাবে ধরুন
            </Paragraph>
          </Card>

          <View style={styles.previewBox}>
            <Text style={styles.previewIcon}>📷</Text>

            <Text style={styles.previewText}>আক্রান্ত অংশের ছবি তুলুন</Text>
          </View>
        </View>

        <TouchableOpacity activeOpacity={0.9} style={styles.openCameraButton}>
          <Paragraph style={styles.openCameraButtonText}>
            {data.buttonText}
          </Paragraph>
        </TouchableOpacity>
      </Card>
    </>
  );
};

export default CameraSection;

const styles = StyleSheet.create({
  cameraContainer: {
    marginTop: 18,
    alignItems: 'center',
  },

  cameraTopRow: {
    width: '100%',

    flexDirection: 'row',

    justifyContent: 'space-between',

    alignItems: 'stretch',

    gap: 12,
  },

  cameraPreviewCard: {
    flex: 1,

    backgroundColor: '#F4F7F1',

    // borderRadius: 24,

    alignItems: 'center',

    justifyContent: 'center',
  },

  liveCameraImage: {
    width: 120,

    height: 100,
  },

  previewBox: {
    flex: 1,

    height: 160,

    borderRadius: 24,

    borderWidth: 2,

    borderColor: '#CBD5E1',

    borderStyle: 'dashed',

    justifyContent: 'center',

    alignItems: 'center',

    backgroundColor: '#F8FAFC',
  },

  previewIcon: {
    fontSize: 48,
  },

  previewText: {
    marginTop: 10,

    fontSize: 12,

    fontWeight: '600',

    color: '#475569',

    textAlign: 'center',
  },

  openCameraButton: {
    marginTop: 24,

    width: '100%',

    backgroundColor: '#1565C0',

    paddingVertical: 16,

    borderRadius: 18,

    justifyContent: 'center',

    alignItems: 'center',
  },

  openCameraButtonText: {
    color: '#FFFFFF',

    fontSize: 16,

    fontWeight: '800',
  },
});
